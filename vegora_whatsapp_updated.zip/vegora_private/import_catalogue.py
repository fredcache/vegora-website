#!/usr/bin/env python3
"""
Vegora catalogue importer (handbags, solar, gaming).

1. Edit supplier_catalogue.csv  (category, cost, market_price, image_urls ...)
2. Run:  python3 import_catalogue.py
3. It downloads images into ../vegora_work/images/products/ and writes
   ../vegora_work/handbags.csv, solar.csv and gaming.csv with SELLING prices.

Supplier cost, cost_basis, supplier_link and the supplier's name are NEVER
written to the website folder. Deploy only vegora_work, never this folder.
"""
import csv, os, re, sys, urllib.request, urllib.parse

# ---- CHANGE THESE -------------------------------------------------------
# Markup shrinks as the item gets more expensive, so big items stay at a fair
# market price while cheap items still get the full 2.5x.
# (up to this cost, multiplier applied to the slice of cost in that band)
BANDS = [(20, 2.5), (100, 1.8), (300, 1.35), (1000, 1.15), (float("inf"), 1.08)]
MARKET_DISCOUNT = 0.97      # if market_price is given, sell at 97% of it (a good deal)
MIN_MARGIN = 1.10           # never sell below cost x 1.10
# -------------------------------------------------------------------------

HERE = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(HERE, "..", "vegora_work")
IMG_DIR = os.path.join(SITE, "images", "products")
SRC = os.path.join(HERE, "supplier_catalogue.csv")
CATEGORIES = ("handbags", "solar", "gaming")
OUT_COLS = ["product_name","description","price","currency","moq","colours",
            "image","images","video_url","supplier_link","status"]
# words that must never appear on the public site
SCRUB = re.compile(r"made[\s-]*in[\s-]*china(\.com)?|madeinchina|alibaba|1688|aliexpress", re.I)

def clean(text):
    return re.sub(r"\s{2,}", " ", SCRUB.sub("", text or "")).strip(" ,-")

def slug(text):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:30] or "product"

def ext_of(url, ctype):
    path = urllib.parse.urlparse(url).path.lower()
    for e in (".webp", ".jpg", ".jpeg", ".png"):
        if path.endswith(e):
            return e
    return {"image/webp": ".webp", "image/png": ".png"}.get(ctype, ".jpg")

def download(url, base):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        ctype = r.headers.get("Content-Type", "").split(";")[0]
        if ctype and not ctype.startswith("image/"):
            raise ValueError(f"not an image ({ctype})")
        name = base + ext_of(url, ctype)
        with open(os.path.join(IMG_DIR, name), "wb") as f:
            f.write(r.read())
    return name

def selling_price(cost, market=None, name=""):
    cost = float(cost)
    price, low = 0.0, 0.0
    for top, mult in BANDS:
        if cost > low:
            price += (min(cost, top) - low) * mult
        low = top
    if market:
        price = min(price, float(market) * MARKET_DISCOUNT)
    floor = cost * MIN_MARGIN
    if price < floor:
        print(f"  ! {name[:40]}: market price leaves under {int((MIN_MARGIN-1)*100)}% margin; price raised to cost x {MIN_MARGIN}")
        price = floor
    price = round(price) if price >= 50 else round(price, 2)
    return f"{price:.2f}"

def main():
    os.makedirs(IMG_DIR, exist_ok=True)
    out = {c: [] for c in CATEGORIES}
    with open(SRC, newline="", encoding="utf-8-sig") as f:
        for n, row in enumerate(csv.DictReader(f), start=1):
            name = clean(row.get("product_name"))
            cat = (row.get("category") or "").strip().lower()
            if not name or cat not in out:
                if name:
                    print(f"  ! {name[:40]}: category must be one of {CATEGORIES}")
                continue
            cost = (row.get("cost") or "").strip().replace(",", "")
            try:
                price = selling_price(cost, (row.get("market_price") or "").strip().replace(",",""), name) if cost else ""
            except ValueError:
                print(f"  ! {name[:40]}: cost '{cost}' is not a number")
                price = ""
            saved = []
            urls = [u.strip() for u in (row.get("image_urls") or "").split("|") if u.strip()]
            for i, url in enumerate(urls, start=1):
                try:
                    saved.append(download(url, f"{cat}-{n}-{slug(name)}-{i}"))
                except Exception as e:
                    if urllib.parse.urlparse(url).netloc.endswith("netlify.app"):
                        saved.append(url)   # your own live site: keep the link
                    else:
                        print(f"  ! {name[:40]} image {i} failed: {e}")
            print(f"  ok  [{cat}] {name[:50]}  images: {len(saved)}/{len(urls)}")
            out[cat].append({
                "product_name": name, "description": clean(row.get("description")),
                "price": price, "currency": row.get("currency") or "USD",
                "moq": row.get("moq", ""), "colours": row.get("colours", ""),
                "image": "", "images": "|".join(saved), "video_url": "",
                "supplier_link": "", "status": row.get("status") or "published",
            })
    for cat, rows in out.items():
        with open(os.path.join(SITE, f"{cat}.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=OUT_COLS)
            w.writeheader(); w.writerows(rows)
        print(f"{cat}.csv: {len(rows)} products")
    print("\nCost -> selling price examples:")
    for c in (5, 20, 50, 100, 250, 500, 1000):
        sp = float(selling_price(c)); print(f"  ${c:>5} -> ${sp:>8.2f}  (x{sp/c:.2f})")

if __name__ == "__main__":
    sys.exit(main())
