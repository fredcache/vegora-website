Place your supplier-authorised product images in this folder.
Use simple filenames such as structured-black-bag.jpg.
Enter that exact filename in the image column of handbags.csv.
Do not use supplier images unless the supplier has authorised commercial reuse.
