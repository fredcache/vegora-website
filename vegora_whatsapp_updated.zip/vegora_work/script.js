// Vegora contact and catalogue behaviour. WhatsApp number in international format, without +.
const VEGORA_WHATSAPP = '254718267222';

document.getElementById('year')?.append(new Date().getFullYear());

function openVegoraWhatsApp(message){
  const url = `https://wa.me/${VEGORA_WHATSAPP}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank', 'noopener');
}

function sendEnquiry(event, category='General enquiry'){
  event.preventDefault();
  const form=event.target, data=new FormData(form);
  const message = `Hello Vegora, I have a ${category}.\nName: ${data.get('name')||'Not provided'}\nMy email/WhatsApp: ${data.get('contact')||'Not provided'}\nRequirements: ${data.get('message')||'Please contact me.'}`;
  openVegoraWhatsApp(message);
}

function parseCSV(text){
  const rows=[]; let row=[], cell='', quoted=false;
  for(let i=0;i<text.length;i++){
    const c=text[i], next=text[i+1];
    if(c==='"' && quoted && next==='"'){cell+='"';i++;}
    else if(c==='"'){quoted=!quoted;}
    else if(c===',' && !quoted){row.push(cell.trim());cell='';}
    else if((c==='\n'||c==='\r') && !quoted){if(c==='\r'&&next==='\n')i++;row.push(cell.trim());if(row.some(v=>v!==''))rows.push(row);row=[];cell='';}
    else cell+=c;
  }
  row.push(cell.trim()); if(row.some(v=>v!==''))rows.push(row);
  if(!rows.length)return [];
  const headers=rows.shift().map(h=>h.toLowerCase());
  return rows.map(values=>Object.fromEntries(headers.map((h,i)=>[h,values[i]||''])));
}

async function loadCatalogue(){
  const grid=document.getElementById('product-grid');
  const empty=document.getElementById('catalogue-empty');
  if(!grid)return;
  try{
    const response=await fetch(grid.dataset.catalogue||'handbags.csv');
    if(!response.ok)throw new Error('Catalogue file not found');
    const products=parseCSV(await response.text()).filter(p=>(p.status||'published').toLowerCase()==='published' && p.product_name);
    if(!products.length){empty.hidden=false;return;}
    empty.hidden=true;
    grid.innerHTML=products.map((p,index)=>{
      const images=(p.images||p.image||'').split('|').map(s=>s.trim()).filter(Boolean).map(s=>safeURL(s)).filter(s=>s!=='#');
      const gallery=images.length ? `<div class="product-gallery"><div class="gallery-main"><img src="${images[0]}" alt="${escapeHTML(p.product_name)} product view" loading="lazy" onerror="this.closest('.gallery-main').innerHTML='<div class=\'product-placeholder\'>Product photos coming soon</div>'"></div>${images.length>1?`<div class="gallery-thumbs">${images.map((src,i)=>`<button type="button" class="gallery-thumb ${i===0?'active':''}" aria-label="View product angle ${i+1}" onclick="setGalleryImage(this,'${escapeAttr(src)}')"><img src="${src}" alt="View ${i+1}" loading="lazy"></button>`).join('')}</div>`:''}</div>`:'<div class="product-image product-placeholder">Product photos coming soon</div>';
      const price=p.price ? `${escapeHTML(p.currency||'USD')} ${escapeHTML(p.price)}` : 'Request wholesale quote';
      const moq=p.moq ? `<p class="product-meta"><b>Minimum order:</b> ${escapeHTML(p.moq)}</p>` : '';
      const message=`Hello Vegora, I am interested in: ${p.product_name}\nQuantity: Please advise\nDestination country: [Please add]\nPlease send available colours, specifications and a wholesale quotation.`;
      const addBtn=(parseFloat(p.price)>0)?`<button type="button" class="button button-gold add-cart" data-name="${escapeAttr(p.product_name)}" data-price="${escapeAttr(p.price)}" data-currency="${escapeAttr(p.currency||'USD')}" data-moq="${escapeAttr(p.moq||'')}" data-img="${escapeAttr(images[0]||'')}">Add to cart</button>`:'';
      return `<article class="product-card">${gallery}<div class="product-card-body"><p class="product-price">${price}</p><h3>${escapeHTML(p.product_name)}</h3><p class="product-description">${escapeHTML(p.description||'Ask Vegora about available specifications, colours and wholesale supply.')}</p>${moq}<div class="product-actions">${addBtn}<a class="button button-dark product-quote" href="https://wa.me/${VEGORA_WHATSAPP}?text=${encodeURIComponent(message)}" target="_blank" rel="noopener">Enquire on WhatsApp ↗</a></div></div></article>`;
    }).join('');
  }catch(error){empty.hidden=false;empty.textContent='The product catalogue could not be loaded. Please try again later.';}
}
function setGalleryImage(button,src){
  const gallery=button.closest('.product-gallery');
  gallery.querySelector('.gallery-main img')?.setAttribute('src',src);
  gallery.querySelectorAll('.gallery-thumb').forEach(b=>b.classList.toggle('active',b===button));
}
function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function escapeAttr(value){return String(value).replace(/&/g,'&amp;').replace(/'/g,'&#39;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function safeURL(value){try{const u=new URL(value,window.location.href);return ['https:'].includes(u.protocol)?u.href:'#';}catch{return '#';}}
loadCatalogue();
