VEGORA GLOBAL MARKETPLACE — WHATSAPP ENQUIRY WEBSITE

WHAT THIS VERSION CHANGES
- Product and general enquiry forms open WhatsApp for +254 718 267 222.
- Product enquiry buttons include the product name in the pre-filled message.
- Supplier details and supplier links are not displayed on product cards.
- Handbag catalogue supports multiple product images using the images column, separated by |.
- The four handbag listings supplied by the owner are included; supplier prices are not shown as Vegora selling prices.

IMPORTANT BEFORE PUBLISHING
- The current package only has one known image URL per product, and those URLs may or may not still exist on the live site.
- To show many real angles, obtain a supplier-authorised image pack for each model and add the image URLs or image files to the images column. Do not invent product angles or use images without commercial permission.
- Verify MOQ, stock, materials, price and shipping before confirming a quote.
- The supplier_link column is for private sourcing reference only and is not rendered publicly.

ADDING MULTIPLE PHOTOS
- Add image URLs or filenames separated by | in the images column.
- For local images, put files in images/products/ and use filenames there.
- Add one product per CSV row; status=published displays it and status=draft hides it.

PUBLISHING
- Extract this ZIP and drag the website files/folders (not the ZIP itself) into Netlify Deploy manually, or upload the ZIP if using the Netlify deploy workflow.
- Preview and test the live URL before advertising it.

IMPORTING FROM YOUR SUPPLIERS (2.5x PRICE)
- Do NOT deploy the vegora_private folder. Only deploy vegora_work.
- vegora_private/supplier_catalogue.csv holds your costs, MOQs and image links for handbags, solar and gaming.
- Run:  python3 vegora_private/import_catalogue.py   (needs internet)
- It downloads the images into images/products/ and rewrites handbags.csv, solar.csv, gaming.csv with selling prices.
- Pricing: cost up to $20 is sold at 2.5x. The markup shrinks on the more expensive part of the cost (see BANDS at the top of import_catalogue.py), so big items stay at a fair market price.
- Optional market_price column in supplier_catalogue.csv: the item is then sold at 97% of that market price, but never below cost x 1.10 (a warning is printed if the margin is squeezed).
- Run it BEFORE redeploying so your existing live handbag photos are kept.
- cost_basis says whether a cost came from a supplier listing or is an ESTIMATE to confirm.

CART AND CARD PAYMENTS
- Every priced product has an "Add to cart" button. The cart remembers items in the buyer's browser.
- Quantity starts at the product's MOQ and cannot go below it.
- Buyers only type their WhatsApp number. "Order on WhatsApp" sends the full order (items, total, number) to your WhatsApp.
- Card providers require an email, so one is made automatically from the buyer's number.
- "Pay by card" opens Paystack or Flutterwave's secure popup (Visa / Mastercard). Card numbers never touch this website.
- TO SWITCH ON: open cart.js, set provider ('paystack' or 'flutterwave') and paste your PUBLIC key into publicKey. Never paste a secret key.
- Make sure the currency (USD) is enabled on your payment account, or change currency in cart.js.
- Until a key is added, "Pay by card" tells the buyer to order on WhatsApp.
- ALWAYS check the payment in your Paystack/Flutterwave dashboard (amount and reference) before shipping. The amount is set in the buyer's browser, so the dashboard is your proof of payment.
- The cart total excludes shipping and duties; confirm those on WhatsApp.
