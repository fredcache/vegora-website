// Vegora cart + card checkout.
// Card details are typed into the payment provider's own secure popup, never on this site.
//
// TO SWITCH ON CARD PAYMENTS: create a Paystack or Flutterwave account, then paste your
// PUBLIC key below (never the secret key). Leave publicKey empty to keep card payments off.
const VEGORA_PAY = {
  provider: 'paystack',      // 'paystack' or 'flutterwave'
  publicKey: '',             // e.g. 'pk_live_xxx' (Paystack) or 'FLWPUBK-xxx' (Flutterwave)
  currency: 'USD'            // must be enabled on your payment account
};

(function(){
  const KEY = 'vegora_cart';
  let items = [];
  try { items = JSON.parse(localStorage.getItem(KEY) || '[]'); if(!Array.isArray(items)) items = []; } catch(e){ items = []; }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(items)); } catch(e){} };
  const esc = v => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money = (n, cur) => `${cur || 'USD'} ${n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}`;
  const minQty = moq => { const m = String(moq||'').replace(/,/g,'').match(/\d+/); return m ? Math.max(1, parseInt(m[0],10)) : 1; };
  const cur = () => (items[0] && items[0].currency) || 'USD';
  const total = () => items.reduce((s,i) => s + i.price * i.qty, 0);
  const count = () => items.reduce((s,i) => s + i.qty, 0);

  // ---- markup -----------------------------------------------------------
  const pill = document.createElement('button');
  pill.type = 'button'; pill.className = 'cart-pill'; pill.hidden = true;
  pill.setAttribute('aria-label', 'Open cart');
  const drawer = document.createElement('div');
  drawer.className = 'cart-overlay'; drawer.hidden = true;
  drawer.innerHTML = `
  <aside class="cart-drawer" role="dialog" aria-modal="true" aria-labelledby="cart-title">
    <div class="cart-head"><h2 id="cart-title">Your cart</h2><button type="button" class="cart-close" aria-label="Close cart">✕</button></div>
    <div class="cart-body">
      <ul class="cart-list"></ul>
      <p class="cart-empty" hidden>Your cart is empty. Add products from the catalogue.</p>
      <form class="cart-form" novalidate onsubmit="return false">
        <label>Your WhatsApp number<input name="phone" type="tel" inputmode="tel" required autocomplete="tel" placeholder="+254 7XX XXX XXX"></label>
      </form>
    </div>
    <div class="cart-foot">
      <div class="cart-total"><span>Products total</span><b></b></div>
      <p class="cart-note">Shipping and duties are not included. We confirm them with you on WhatsApp.</p>
      <p class="cart-msg" role="status" hidden></p>
      <button type="button" class="button button-gold cart-pay">Pay by card (Visa / Mastercard)</button>
      <button type="button" class="button button-dark cart-wa">Order on WhatsApp</button>
    </div>
  </aside>`;
  document.body.append(pill, drawer);
  const $ = s => drawer.querySelector(s);
  const list = $('.cart-list'), form = $('.cart-form'), msg = $('.cart-msg');

  function say(text){ msg.textContent = text || ''; msg.hidden = !text; }

  function render(){
    const n = count();
    pill.hidden = n === 0;
    pill.textContent = `Cart · ${n} item${n===1?'':'s'} · ${money(total(), cur())}`;
    list.innerHTML = items.map((i,idx) => `
      <li class="cart-item">
        ${i.img ? `<img src="${esc(i.img)}" alt="" loading="lazy">` : '<div class="cart-noimg"></div>'}
        <div class="cart-item-info">
          <b>${esc(i.name)}</b>
          <small>${money(i.price, i.currency)} each${i.min>1 ? ` · minimum ${i.min}` : ''}</small>
          <div class="cart-qty">
            <button type="button" data-act="dec" data-i="${idx}" aria-label="Fewer">−</button>
            <input type="number" min="${i.min}" value="${i.qty}" data-act="set" data-i="${idx}" aria-label="Quantity">
            <button type="button" data-act="inc" data-i="${idx}" aria-label="More">+</button>
            <button type="button" class="cart-remove" data-act="del" data-i="${idx}">Remove</button>
          </div>
        </div>
        <span class="cart-line">${money(i.price*i.qty, i.currency)}</span>
      </li>`).join('');
    $('.cart-empty').hidden = items.length > 0;
    form.hidden = !items.length;
    $('.cart-foot').hidden = !items.length;
    $('.cart-total b').textContent = money(total(), cur());
  }

  function open(){ drawer.hidden = false; document.body.classList.add('cart-open'); render(); $('.cart-close').focus(); }
  function close(){ drawer.hidden = true; document.body.classList.remove('cart-open'); pill.focus?.(); }

  // ---- events -----------------------------------------------------------
  pill.addEventListener('click', open);
  $('.cart-close').addEventListener('click', close);
  drawer.addEventListener('click', e => { if(e.target === drawer) close(); });
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && !drawer.hidden) close(); });

  list.addEventListener('click', e => {
    const b = e.target.closest('button[data-act]'); if(!b) return;
    const i = +b.dataset.i, it = items[i]; if(!it) return;
    if(b.dataset.act === 'inc') it.qty++;
    if(b.dataset.act === 'dec') it.qty = Math.max(it.min, it.qty - 1);
    if(b.dataset.act === 'del') items.splice(i,1);
    save(); render();
  });
  list.addEventListener('change', e => {
    const f = e.target.closest('input[data-act="set"]'); if(!f) return;
    const it = items[+f.dataset.i]; if(!it) return;
    const v = parseInt(f.value,10);
    it.qty = Number.isFinite(v) ? Math.max(it.min, v) : it.min;
    save(); render();
  });

  document.addEventListener('click', e => {
    const b = e.target.closest('.add-cart'); if(!b) return;
    const d = b.dataset, price = parseFloat(d.price); if(!(price > 0)) return;
    const id = d.name.toLowerCase();
    const found = items.find(i => i.id === id);
    if(found) found.qty++;
    else { const min = minQty(d.moq); items.push({id, name:d.name, price, currency:d.currency||'USD', moq:d.moq||'', min, qty:min, img:d.img||''}); }
    save(); render();
    const old = b.textContent; b.textContent = 'Added ✓'; b.disabled = true;
    setTimeout(() => { b.textContent = old; b.disabled = false; }, 1400);
  });

  // ---- checkout ---------------------------------------------------------
  function details(){
    const phone = (form.elements['phone'].value || '').trim();
    if(phone.replace(/\D/g,'').length < 7){ say('Enter your WhatsApp number so we can confirm your order.'); form.elements['phone'].focus(); return null; }
    return {phone};
  }
  function orderText(c, paidRef){
    const lines = items.map(i => `• ${i.name} × ${i.qty} @ ${money(i.price,i.currency)} = ${money(i.price*i.qty,i.currency)}`).join('\n');
    return `Hello Vegora, ${paidRef ? 'I have PAID by card (ref ' + paidRef + ').' : 'I would like to place this order.'}\n\n${lines}\n\nProducts total: ${money(total(),cur())}\n\nMy WhatsApp: ${c.phone}\n\nPlease confirm shipping cost and delivery time.`;
  }
  function finish(c, ref){
    openVegoraWhatsApp(orderText(c, ref));
    items = []; save(); render(); close();
  }

  $('.cart-wa').addEventListener('click', () => {
    const c = details(); if(!c) return; say('');
    finish(c, null);
  });

  function loadScript(src){
    return new Promise((ok, fail) => {
      if(document.querySelector(`script[src="${src}"]`)) return ok();
      const s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = () => fail(new Error('load'));
      document.head.appendChild(s);
    });
  }

  $('.cart-pay').addEventListener('click', async () => {
    const c = details(); if(!c) return; say('');
    if(!VEGORA_PAY.publicKey){ say('Card payment is not switched on yet. Please use “Order on WhatsApp” and we will send you a payment link.'); return; }
    const ref = 'VEG-' + Date.now(), amount = Math.round(total()*100)/100;
    const email = c.phone.replace(/\D/g,'') + '@' + (location.hostname || 'vegora.shop');   // providers require an email
    try {
      if(VEGORA_PAY.provider === 'flutterwave'){
        await loadScript('https://checkout.flutterwave.com/v3.js');
        FlutterwaveCheckout({
          public_key: VEGORA_PAY.publicKey, tx_ref: ref, amount, currency: VEGORA_PAY.currency,
          payment_options: 'card', customer: {email, phone_number:c.phone, name:'Vegora customer'},
          customizations: {title:'Vegora Global Marketplace', description:'Product order'},
          callback: function(r){ if(r && (r.status === 'successful' || r.status === 'completed')) finish(c, ref); else say('Payment was not completed. You have not been charged for an incomplete payment.'); },
          onclose: function(){}
        });
      } else {
        await loadScript('https://js.paystack.co/v1/inline.js');
        PaystackPop.setup({
          key: VEGORA_PAY.publicKey, email, amount: Math.round(amount*100), currency: VEGORA_PAY.currency, ref,
          metadata: {custom_fields:[{display_name:'Customer', variable_name:'customer', value:c.phone}]},
          callback: function(){ finish(c, ref); },
          onClose: function(){}
        }).openIframe();
      }
    } catch(err){ say('Could not open the card payment window. Check your connection or order on WhatsApp.'); }
  });

  render();
})();
